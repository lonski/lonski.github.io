package pl.lonski.unchecker;

import java.util.function.BiConsumer;
import java.util.function.Consumer;
import java.util.function.Supplier;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class Unchecker {

	private static final Logger LOGGER = LoggerFactory.getLogger(Unchecker.class);

	private Unchecker() {
	}

	public static <T> T exec(ThrowingSupplier<T> supplier) {
		return exec(supplier, UncheckedException.class);
	}

	public static <T> T exec(ThrowingSupplier<T> supplier, Class<? extends RuntimeException> uncheckTo) {
		try {
			return supplier.get();
		} catch (Exception e) {
			throw createException(e, uncheckTo);
		}
	}

	public static void run(ThrowingRunnable runnable) {
		run(runnable, UncheckedException.class);
	}

	public static void run(ThrowingRunnable runnable, Class<? extends RuntimeException> uncheckTo) {
		try {
			runnable.run();
		} catch (Exception e) {
			throw createException(e, uncheckTo);
		}
	}

	public static Runnable uncheck(ThrowingRunnable runnable) {
		return uncheck(runnable, UncheckedException.class);
	}

	public static Runnable uncheck(
			ThrowingRunnable runnable,
			Class<? extends RuntimeException> uncheckTo) {
		return () -> {
			try {
				runnable.run();
			} catch (Exception e) {
				throw createException(e, uncheckTo);
			}
		};
	}

	public static <T> Consumer<T> uncheck(ThrowingConsumer<T> consumer) {
		return uncheck(consumer, UncheckedException.class);
	}

	public static <T> Consumer<T> uncheck(ThrowingConsumer<T> consumer, Class<? extends RuntimeException> uncheckTo) {
		return (T t) -> {
			try {
				consumer.accept(t);
			} catch (Exception e) {
				throw createException(e, uncheckTo);
			}
		};
	}

	public static <T, U> BiConsumer<T, U> uncheck(ThrowingBiConsumer<T, U> consumer) {
		return uncheck(consumer, UncheckedException.class);
	}

	public static <T, U> BiConsumer<T, U> uncheck(ThrowingBiConsumer<T, U> consumer,
			Class<? extends RuntimeException> uncheckTo) {
		return (T t, U u) -> {
			try {
				consumer.accept(t, u);
			} catch (Exception e) {
				throw createException(e, uncheckTo);
			}
		};
	}

	public static <T> Supplier<T> uncheck(ThrowingSupplier<T> supplier) {
		return uncheck(supplier, UncheckedException.class);
	}

	public static <T> Supplier<T> uncheck(ThrowingSupplier<T> supplier, Class<? extends RuntimeException> uncheckTo) {
		return () -> {
			try {
				return supplier.get();
			} catch (Exception e) {
				throw createException(e, uncheckTo);
			}
		};
	}

	private static RuntimeException createException(
			Exception caughtException,
			Class<? extends RuntimeException> uncheckTo) {
		try {
			LOGGER.debug("Unchecking exception: ", caughtException);
			return uncheckTo.getConstructor(Exception.class).newInstance(caughtException);
		} catch (Exception failedToInstantiateRequestedException) {
			return new UncheckedException(caughtException);
		}
	}
}

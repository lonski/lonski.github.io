package pl.lonski.unchecker;

public class UncheckedException extends RuntimeException {
	public UncheckedException(Exception e) {
		super(e);
	}
}

package pl.lonski.unchecker;

@FunctionalInterface
public interface ThrowingRunnable {
	void run() throws Exception;
}

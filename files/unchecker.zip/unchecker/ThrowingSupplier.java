package pl.lonski.unchecker;

@FunctionalInterface
public interface ThrowingSupplier<T> {
	T get() throws Exception;
}

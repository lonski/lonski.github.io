package pl.lonski.unchecker;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.catchThrowable;

import java.io.IOException;
import java.lang.reflect.Constructor;
import java.lang.reflect.Modifier;
import java.util.Random;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import java.util.function.Supplier;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.junit.Test;

class TestException extends RuntimeException {
	public TestException(Exception e) {
		super(e);
	}
}

class TestExceptionWithIncorrectConstructor extends RuntimeException {
	public TestExceptionWithIncorrectConstructor() {
		super("bah");
	}
}

public class UncheckerTest {

	private static boolean flag;

	@Test
	public void shouldHavePrivateConstructor() throws Exception {
		Constructor<Unchecker> constructor = Unchecker.class.getDeclaredConstructor();

		assertThat(Modifier.isPrivate(constructor.getModifiers())).isTrue();
	}

	@Test
	public void shouldExecSupplier() {
		int testVal = new Random().nextInt();

		int retValue = Unchecker.exec(() -> testVal);

		assertThat(retValue).isEqualTo(testVal);
	}

	@Test
	public void shouldUncheckExceptionOnExec() {
		final String msg = generateRandomMessage();

		Throwable throwable = catchThrowable(() -> Unchecker.exec(() -> {
			throw new IOException(msg);
		}));

		assertThat(throwable).isInstanceOf(UncheckedException.class);
		assertThat(throwable.getMessage()).contains(msg);
	}

	@Test
	public void shouldUncheckExceptionToDefinedTypeOnExec() {
		final String msg = generateRandomMessage();

		Throwable throwable = catchThrowable(() -> Unchecker.exec(() -> {
			throw new IOException(msg);
		}, TestException.class));

		assertThat(throwable).isInstanceOf(TestException.class);
		assertThat(throwable.getMessage()).contains(msg);
	}

	@Test
	public void shouldUncheckExceptionOnRun() {
		final String msg = generateRandomMessage();
		ThrowingRunnable runnable = () -> {
			throw new IOException(msg);
		};

		Throwable throwable = catchThrowable(() -> Unchecker.run(runnable));

		assertThat(throwable).isInstanceOf(UncheckedException.class);
		assertThat(throwable.getMessage()).contains(msg);
	}

	@Test
	public void shouldUncheckThrowingRunnable() {
		flag = false;
		ThrowingRunnable throwingRunnable = () -> flag = true;

		Runnable runnable = Unchecker.uncheck(throwingRunnable);
		runnable.run();

		assertThat(flag).isTrue();
	}

	@Test
	public void shouldUncheckThrowingSupplier() {
		int magicNumber = 5;
		ThrowingSupplier<Integer> throwingSupplier = () -> magicNumber;

		Supplier<Integer> supplier = Unchecker.uncheck(throwingSupplier);

		assertThat(supplier.get()).isEqualTo(magicNumber);
	}

	@Test
	public void shouldUncheckThrowingConsumer() {
		int magicNumber = 5;
		ThrowingConsumer<Integer> throwingConsumer = (Integer arg) -> {
			if (arg != magicNumber) {
				throw new Exception();
			}
		};

		Consumer<Integer> consumer = Unchecker.uncheck(throwingConsumer);
		consumer.accept(magicNumber);

		//no exception thrown
	}

	@Test
	public void shouldUncheckThrowingBiConsumer() {
		int magicNumber = 5;
		String magicMsg = "puff!";
		ThrowingBiConsumer<Integer, String> throwingConsumer = (Integer arg, String strarg) -> {
			if (arg != magicNumber) {
				throw new Exception(strarg);
			}
		};

		BiConsumer<Integer, String> consumer = Unchecker.uncheck(throwingConsumer);
		consumer.accept(magicNumber, magicMsg);

		//no exception thrown
	}

	@Test
	public void shouldExecuteRunnable() {
		flag = false;

		Unchecker.run(() -> flag = true);

		assertThat(flag).isTrue();
	}

	@Test
	public void shouldUncheckThrowingRunnableWithDefinedException() {
		final String msg = generateRandomMessage();
		ThrowingRunnable throwingRunnable = () -> {
			throw new IOException(msg);
		};

		Runnable runnable = Unchecker.uncheck(throwingRunnable, TestException.class);
		Throwable throwable = catchThrowable(runnable::run);

		assertThat(throwable).isInstanceOf(TestException.class);
		assertThat(throwable.getMessage()).contains(msg);
	}

	@Test
	public void shouldUncheckThrowingSupplierWithDefinedException() {
		final String msg = generateRandomMessage();
		ThrowingSupplier<Integer> throwingSupplier = () -> {
			throw new IOException(msg);
		};

		Supplier<Integer> supplier = Unchecker.uncheck(throwingSupplier, TestException.class);
		Throwable throwable = catchThrowable(supplier::get);

		assertThat(throwable).isInstanceOf(TestException.class);
		assertThat(throwable.getMessage()).contains(msg);
	}

	@Test
	public void shouldUncheckThrowingConsumerWithDefinedException() {
		final String msg = generateRandomMessage();
		ThrowingConsumer<String> throwingConsumer = m -> {
			throw new IOException(m);
		};

		Consumer<String> consumer = Unchecker.uncheck(throwingConsumer, TestException.class);
		Throwable throwable = catchThrowable(() -> consumer.accept(msg));

		assertThat(throwable).isInstanceOf(TestException.class);
		assertThat(throwable.getMessage()).contains(msg);
	}

	@Test
	public void shouldUncheckThrowingBiConsumerWithDefinedException() {
		final String msg = generateRandomMessage();
		ThrowingBiConsumer<Integer, String> throwingConsumer = (i, m) -> {
			throw new IOException(m);
		};

		BiConsumer<Integer, String> consumer = Unchecker.uncheck(throwingConsumer, TestException.class);
		Throwable throwable = catchThrowable(() -> consumer.accept(1, msg));

		assertThat(throwable).isInstanceOf(TestException.class);
		assertThat(throwable.getMessage()).contains(msg);
	}

	@Test
	public void shouldThrowUncheckedExceptionIfCantInstantiateGivenExceptionType() {
		final String msg = generateRandomMessage();
		ThrowingRunnable runnable = () -> {
			throw new IOException(msg);
		};

		Throwable throwable = catchThrowable(
				() -> Unchecker.run(runnable, TestExceptionWithIncorrectConstructor.class)
		);

		assertThat(throwable).isInstanceOf(UncheckedException.class);
		assertThat(throwable.getMessage()).contains(msg);
	}

	private static String generateRandomMessage() {
		final Random random = new Random();
		final char[] letters = "    abcdefghijklmnopqrstuvwxyz".toCharArray();
		return
				IntStream.range(20, 80)
						.mapToObj(n -> letters[random.nextInt(letters.length)])
						.map(String::valueOf)
						.collect(Collectors.joining());
	}
}
